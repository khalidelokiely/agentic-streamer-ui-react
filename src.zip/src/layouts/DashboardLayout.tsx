import * as React from "react";
import { Outlet } from "react-router-dom";
import { Sidebar } from "../components/navigation/Sidebar";
import { SidebarItem } from "../components/navigation/SidebarItem";

export const DashboardLayout: React.FC = () => {
    // Hardcoded for now—this will connect to your local storage tracking hooks later
    const watchedCount = 3;
    const [isCollapsed, setIsCollapsed] = React.useState(false);

    return (
        <div className="w-screen h-screen flex overflow-hidden bg-slate-900 text-slate-100 antialiased">
            <Sidebar>
                <SidebarItem to="/" label="Available Agents" />
                <SidebarItem to="/watchlist" label="Watch List" badgeCount={watchedCount} />
            </Sidebar>
            <main className="flex-1 h-full overflow-y-auto relative p-8 box-border">
                <div className="max-w-6xl mx-auto w-full">
                    <Outlet />
                </div>
            </main>
        </div>
    );
};