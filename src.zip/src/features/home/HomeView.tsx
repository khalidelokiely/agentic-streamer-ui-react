export const HomeView = () => (
    <div className="space-y-4">
        <h1 className="text-2xl font-bold tracking-tight text-white">Available Agents</h1>
        <p className="text-slate-400 text-sm">Select an autonomous agent context to monitor or subscribe to live pipeline executions.</p>
    </div>
);