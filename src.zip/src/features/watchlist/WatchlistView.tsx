export const WatchlistView = () => (
    <div className="space-y-4">
        <h1 className="text-2xl font-bold tracking-tight text-white">Live Watch List</h1>
        <p className="text-slate-400 text-sm">Active streaming loops re-hydrated from local cache metrics.</p>
    </div>
);