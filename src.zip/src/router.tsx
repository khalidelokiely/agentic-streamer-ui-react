import { createBrowserRouter } from "react-router-dom";
import { DashboardLayout } from "./layouts/DashboardLayout";
import { HomeView } from "./features/home/HomeView";
import { WatchlistView } from "./features/watchlist/WatchListView";

export const router = createBrowserRouter([
    {
        path: "/",
        element: <DashboardLayout />,
        children: [
            {
                index: true, // Acts as the root path dashboard matching "/"
                element: <HomeView />,
            },
            {
                path: "watchlist", // Matches "/watchlist"
                element: <WatchlistView />,
            },
        ],
    },
]);