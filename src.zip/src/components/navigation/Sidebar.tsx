export const Sidebar: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    return (
        <nav className="w-64 h-screen bg-slate-950 border-r border-slate-900 flex flex-col justify-between p-4 box-border shrink-0" aria-label="Main Navigation">
            <div className="space-y-6">
                <div className="flex items-center gap-2 px-2 py-1">
                    <div className="h-2 w-2 rounded-full bg-cyan-500 animate-pulse" />
                    <span className="text-xs font-mono font-bold tracking-widest text-slate-400 uppercase">Streamer.IO</span>
                </div>
                <div className="space-y-1">{children}</div>
                <button className="w-full px-2 py-1 text-xs font-mono font-bold tracking-widest text-slate-400 uppercase bg-slate-900 rounded hover:bg-slate-800 transition-colors">
                    Close Sidebar
                </button>
            </div>
        </nav>
    );
};