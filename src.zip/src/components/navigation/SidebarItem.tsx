import * as React from "react";
import { NavLink } from "react-router-dom";

export interface SidebarItemProps {
    to: string;
    label: string;
    badgeCount?: number;
    icon?: React.ReactNode;
}

export const SidebarItem: React.FC<SidebarItemProps> = ({ to, label, badgeCount, icon }) => {
    return (
        <NavLink
            to={to}
            className={({ isActive }) =>
                [
                    "w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition-all group outline-none focus-visible:ring-2 focus-visible:ring-cyan-500",
                    isActive ? "bg-slate-800 text-white shadow-sm" : "text-slate-400 hover:bg-slate-900 hover:text-slate-200"
                ].join(" ")
            }
        >
            {({ isActive }) => (
                <>
                    <div className="flex items-center gap-3">
                        {icon && <span className={`transition-colors ${isActive ? "text-cyan-400" : "text-slate-500 group-hover:text-slate-300"}`}>{icon}</span>}
                        <span>{label}</span>
                    </div>
                    {badgeCount !== undefined && badgeCount > 0 && (
                        <span className={`flex h-5 min-w-5 items-center justify-between rounded-full px-1.5 text-xs font-semibold tracking-tight ${isActive ? "bg-cyan-500 text-slate-950" : "bg-slate-800 text-slate-300 group-hover:bg-slate-700"
                            }`}>
                            {badgeCount}
                        </span>
                    )}
                </>
            )}
        </NavLink>
    );
};